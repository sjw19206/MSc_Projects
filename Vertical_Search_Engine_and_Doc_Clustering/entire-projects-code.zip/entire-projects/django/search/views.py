from django.shortcuts import render
from django.http import HttpResponse
from search.custom.comparematch import CompareMatch
import pandas as pd

# Actions
def say_hello(request):

    query =  request.GET.get('query')

    print('request :: ', request)

    print('query :: ', query)

    df = pd.DataFrame()
    res_list = []
    if query is not None:
        obj_comp_match = CompareMatch()
        #data = {'Name':['Karan','Rohit','Sahil','Aryan'],'Age':[23,22,21,24]}
        df = obj_comp_match.compare_and_match(query)
        res_list = obj_comp_match.get_research_details(df)
        
    context = {'res_list' : res_list } 

    return render(request, 'hello.html', context)
