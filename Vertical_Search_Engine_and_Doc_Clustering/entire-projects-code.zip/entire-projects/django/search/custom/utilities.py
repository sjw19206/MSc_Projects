import pandas as pd
import nltk
import string

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.stem.snowball import SnowballStemmer


def load_csv_to_df(file_path, file_name):
    general_df = pd.read_csv(file_path + file_name)
    return general_df


def pre_process_doc(research_keywords):
    # stop words
    stop_words = stopwords.words('english')
    # lemmatize
    wnl = WordNetLemmatizer()
    # stemmer
    sb = SnowballStemmer(language='english')
    # to lower-case
    research_keywords = research_keywords.lower()

    # print('Keyword :: ', research_keywords)

    pro_res_keywords = ''

    research_tokens = word_tokenize(research_keywords)

    for research_token in research_tokens:
        ## remove special characters
        research_token = research_token.translate(str.maketrans('', '', string.punctuation))

        if research_token not in stop_words and len(research_token) > 2:
            if not research_token.isdigit():
                lem_res_token = wnl.lemmatize(research_token)
                # print('lem :: ', lem_res_token)

                stem_res_token = sb.stem(lem_res_token)
                # print('Stem ::', stem_res_token)

                pro_res_keywords = pro_res_keywords + stem_res_token + ' '

    # print('pro-kw :: ', pro_res_keywords)
    return pro_res_keywords.strip()


class EngineUtilities:

    def __init__(self):
        print('Utilities init() ::')
        self.sefa_member_dict = {}
        nltk.download("stopwords")
        nltk.download('wordnet')
        nltk.download('omw-1.4')
        nltk.download('punkt')

    def update_dictionary(self, key_list, value_list):
        for (key, value) in zip(key_list, value_list):
            self.sefa_member_dict[key] = value

        #print(self.sefa_member_dict)

    def create_member_df_save_csv(self, file_path, file_name):
        member_df = pd.DataFrame.from_dict(self.sefa_member_dict)
        member_df.to_csv(file_path + file_name, index=False, mode='w+')

    def save_df_to_csv(self, input_df, file_path, file_name):
        input_df.to_csv(file_path + file_name, index=False, mode='w+')

    def update_dict_create_df(self, key_list, value_list):
        for (key, value) in zip(key_list, value_list):
            self.sefa_member_dict[key] = value

        data_df = pd.DataFrame.from_dict(self.sefa_member_dict)
        return data_df
