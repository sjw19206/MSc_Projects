from search.custom.utilities import load_csv_to_df, EngineUtilities, pre_process_doc
import math as mt
import numpy as np


class CompareMatch:

    def __init__(self):
        print('compare match init :: ')
        self.engine_utilities = EngineUtilities()

    def calc_length_of_vector(self, input_vector):
        sq_list = [i ** 2 for i in input_vector]
        sqrt_sum_ele = mt.sqrt(sum(sq_list))
        # print(sqrt_sum_ele)
        return sqrt_sum_ele

    def compare_and_match(self, inp_string):
        metrics_df = load_csv_to_df("D:\\Development\\Custom_Data\\SearchEngine\\", "METRICS.CSV")
        research_df = load_csv_to_df("D:\\Development\\Custom_Data\\SearchEngine\\", "RESEARCH.CSV")
        tokenized_input = pre_process_doc(inp_string)
        research_id_list = []
        research_similarity_list = []
        similarity_header_list = ['RSCH_ID', 'COS_SIMILARITY']
        similarity_body_list = []
        print('tokenized input :: ', tokenized_input)
        for index in research_df.index:
            research_id = research_df['RSCH_ID'][index]
            print('research_id :: ', research_id)
            research_metrics_df = metrics_df.loc[metrics_df['RSCH_ID'] == research_id]
            # print(research_metrics_df)
            inp_tf_idf = []
            res_tf_idf = []
            for met_index in research_metrics_df.index:
                rsch_token = research_metrics_df['RSCH_TOKEN'][met_index]
                rsch_tf_idf = research_metrics_df['TOKEN_TF_IDF'][met_index]
                print(rsch_token)
                # print(rsch_tf_idf)
                if tokenized_input.count(rsch_token) > 0:
                    inp_tf_idf.append(rsch_tf_idf)
                    res_tf_idf.append(rsch_tf_idf)
                else:
                    inp_tf_idf.append(0)
                    res_tf_idf.append(rsch_tf_idf)

            # print(len(inp_tf_idf))
            # print(inp_tf_idf)
            # print(len(res_tf_idf))
            # print(res_tf_idf)
            vector_product = np.dot(inp_tf_idf, res_tf_idf)
            # print('vector-prod :: ', vector_product)
            input_vector_length = self.calc_length_of_vector(inp_tf_idf)
            res_vector_length = self.calc_length_of_vector(res_tf_idf)
            # print('inp-vector-length :: ', input_vector_length)
            # print('res-vector-length :: ', res_vector_length)
            cosine_similarity = 0
            if input_vector_length > 0 and res_vector_length > 0:
                cosine_similarity = vector_product / (input_vector_length * res_vector_length)
            else:
                cosine_similarity = -1

            # print('cosine-sim :: ', cosine_similarity)
            if cosine_similarity > 0:
                research_id_list.append(research_id)
                research_similarity_list.append(cosine_similarity)
            # break
            print('cosine-similarity:: ', cosine_similarity)
        similarity_body_list.append(research_id_list)
        similarity_body_list.append(research_similarity_list)
        res_match_df = self.engine_utilities.update_dict_create_df(similarity_header_list, similarity_body_list)
        print('res-match-df ::: ', res_match_df)
        return res_match_df.sort_values(by='COS_SIMILARITY', ascending=False)

    def get_research_details(self, res_match_df):
        research_df = load_csv_to_df("D:\\Development\\Custom_Data\\SearchEngine\\", "RESEARCH.CSV")
        research_list = []
        for index in res_match_df.index:
            research_id = res_match_df['RSCH_ID'][index]
            research_match_df = research_df.loc[research_df['RSCH_ID'] == research_id]
            print('------------------------------------')
            research_list.append(research_match_df)            
        return research_list



