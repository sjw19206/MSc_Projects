from django.urls import URLPattern, path
from . import views

#URL Config
urlpatterns = [
    path('', views.say_hello)
]