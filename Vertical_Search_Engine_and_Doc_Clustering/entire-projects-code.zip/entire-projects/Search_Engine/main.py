import time

from org.coventry.collect.membercrawler import MemberCrawler
from org.coventry.collect.researchcrawler import ResearchCrawler
from org.coventry.collect.searchtokenizer import SearchTokenizer
from org.coventry.collect.comparematch import CompareMatch
import time as ts
import schedule as sch


def member_crawler():
    print('member-crawler is invoked ::: ')
    obj_mem_crawler = MemberCrawler()
    obj_mem_crawler.crawl_save_member_details()
    print('member-crawler is complete ::: ')


def research_crawler():
    print('research-crawler is invoked ::: ')
    obj_res_crawler = ResearchCrawler()
    obj_res_crawler.crawl_save_research_details("D:\\Development\\Custom_Data\\SearchEngine\\", "MEMBERS.csv")
    ts.sleep(9)
    obj_tokenizer = SearchTokenizer()
    obj_tokenizer.pre_process_data("D:\\Development\\Custom_Data\\SearchEngine\\", "RESEARCH.CSV")
    obj_tokenizer.form_se_metrics("D:\\Development\\Custom_Data\\SearchEngine\\", "RESEARCH.CSV")
    print('<----- ::: research-crawler is complete ::: ----->')


sch.every().friday.at("16:50").do(member_crawler)
sch.every().friday.at("16:51").do(research_crawler)

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    while True:
        sch.run_pending()
        time.sleep(5)
