# import statements
import requests as req
import time as ts

from bs4 import BeautifulSoup as bs
from org.coventry.utils.utilities import EngineUtilities
from org.coventry.utils.utilities import load_csv_to_df


class ResearchCrawler:

    def __init__(self):
        print('Research Crawler init() :: ')
        self.sefa_research_sub_query = '/publications/'
        self.engine_utilities = EngineUtilities()

    def crawl_save_research_details(self, file_path, file_name):
        member_name_list = []
        member_id_list = []
        member_url_list = []
        research_title_list = []
        research_url_list = []
        research_keywords_list = []
        research_id_list = []
        research_year_list = []
        research_header_list = ['RSCH_ID', 'RSCH_TITLE', 'RSCH_URL', 'RSCH_YEAR', 'RSCH_KEYWORDS', 'MEMBER_ID',
                                'MEMBER_NAME', 'MEMBER_URL']
        research_body_list = []
        research_id_code = 'RS'
        research_id_counter = 00000
        member_df = load_csv_to_df(file_path, file_name)
        print('dataframe :: \n', member_df)

        for index in member_df.index:
            member_name = member_df['Member_NAME'][index]
            member_id = member_df['Member_ID'][index]
            member_url = member_df['Member_URL'][index]
            print('--------------------INDEX-------------------', index)
            print('URL :: ', member_url)
            print('Name :: ', member_name)

            # research
            publications_url = member_url + self.sefa_research_sub_query
            ts.sleep(1)
            publications_page = req.get(publications_url)
            if publications_page.status_code == 200:
                publications_page_soup = bs(publications_page.text, "html.parser")
                publication_list_counter = 0
                is_iteration_required = True

                while is_iteration_required:
                    publication_list_class = 'list-result-item list-result-item-' + str(publication_list_counter)
                    print('list-class :: ', publication_list_class)
                    publication_list = publications_page_soup.find("li", class_=publication_list_class)
                    # print('list :: ', publication_list)

                    if publication_list is not None:
                        research_details = publication_list.find("a", class_="link", rel="ContributionToJournal")
                        if research_details is None:
                            research_details = publication_list.find("a", class_="link", rel="WorkingPaper")
                            if research_details is None:
                                research_details = publication_list.find("a", class_="link", rel="Thesis")
                                if research_details is None:
                                    research_details = publication_list.find("a", class_="link",
                                                                             rel="ContributionToConference")
                                    if research_details is None:
                                        research_details = publication_list.find("a", class_="link",
                                                                                 rel="ContributionToBookAnthology")
                                        if research_details is None:
                                            research_details = publication_list.find("a", class_="link",
                                                                                     rel="ContributionToPeriodical")
                                            if research_details is None:
                                                research_details = publication_list.find("a", class_="link",
                                                                                         rel="BookAnthology")
                                                if research_details is None:
                                                    research_details = publication_list.find("a", class_="link",
                                                                                             rel="OtherContribution")

                        print('res :: ', research_details)
                        print('Research URL :: ', research_details.attrs['href'])
                        print('Research Title :: ', research_details.text)

                        research_title = research_details.text
                        research_url = research_details.attrs['href']
                        research_keywords = research_details.text
                        research_id = member_id + '_' + research_id_code + str(research_id_counter)
                        research_id_counter += 1
                        ## additional keywords
                        keyword_list = publication_list.find_all("li",
                                                                 class_="concept-badge-small-container dropdown-overflow")
                        print('Keyword list length :: ', len(keyword_list))
                        for keyword in keyword_list:
                            ## print key concepts related to research
                            concept_data = keyword.find('span', class_="concept")
                            print('concept :: ', concept_data.text)
                            keyword = concept_data.text
                            research_keywords = research_keywords.strip() + " " + keyword

                        ## research published month year
                        published_year = publication_list.find("span", class_="date")
                        print('month-year :: ', published_year.text)
                        research_year = published_year.text
                        # add details to list and save
                        member_id_list.append(member_id)
                        member_name_list.append(member_name)
                        research_title_list.append(research_title.strip())
                        research_url_list.append(research_url)
                        research_keywords_list.append(research_keywords.strip())
                        research_year_list.append(research_year)
                        research_id_list.append(research_id)
                        member_url_list.append(member_url)

                    else:
                        is_iteration_required = False

                    publication_list_counter += 1

        research_body_list.append(research_id_list)
        research_body_list.append(research_title_list)
        research_body_list.append(research_url_list)
        research_body_list.append(research_year_list)
        research_body_list.append(research_keywords_list)
        research_body_list.append(member_id_list)
        research_body_list.append(member_name_list)
        research_body_list.append(member_url_list)

        self.engine_utilities.update_dictionary(research_header_list, research_body_list)
        self.engine_utilities.create_member_df_save_csv("D:\\Development\\Custom_Data\\SearchEngine\\",
                                                        "RESEARCH.CSV")
