from org.coventry.utils.utilities import EngineUtilities
from org.coventry.utils.utilities import load_csv_to_df, pre_process_doc
import math as mt


class SearchTokenizer:

    def __init__(self):
        self.engine_utilities = EngineUtilities()
        self.research_tokens_doc_list = []
        self.research_id_list = []
        self.research_token_list = []
        self.research_token_tf_list = []
        self.research_token_idf_list = []
        self.research_token_tf_idf_list = []
        self.research_metric_header_list = ['RSCH_ID', 'RSCH_TOKEN', 'TOKEN_TF', 'TOKEN_IDF', 'TOKEN_TF_IDF']
        self.research_metric_body_list = []

    def pre_process_data(self, file_path, file_name):
        rsch_tokens = []
        research_df = load_csv_to_df(file_path, file_name)

        for index in research_df.index:
            research_keywords = research_df['RSCH_KEYWORDS'][index]

            pro_res_keywords = pre_process_doc(research_keywords)

            rsch_tokens.append(pro_res_keywords)

        research_df['RSCH_TOKENS'] = rsch_tokens
        # print(research_df.head(1))
        self.engine_utilities.save_df_to_csv(research_df, file_path, file_name)

    def count_docs_with_token(self, research_token):
        doc_count = 0
        for doc in self.research_tokens_doc_list:
            if doc.count(research_token) > 0:
                doc_count += 1

        return doc_count

    def calc_tf_idf(self, research_id, research_tokens, research_token):
        token_frequency = research_tokens.count(research_token)
        docs_with_token = self.count_docs_with_token(research_token)
        total_docs = len(self.research_tokens_doc_list)
        tf = mt.log10(1 + token_frequency)
        idf = mt.log10(total_docs / docs_with_token)
        tf_idf = tf * idf
        self.research_id_list.append(research_id)
        self.research_token_list.append(research_token)
        self.research_token_tf_list.append(tf)
        self.research_token_idf_list.append(idf)
        self.research_token_tf_idf_list.append(tf_idf)

    def calc_metrics_for_docs(self, research_id, research_tokens):
        ## convert document to list
        research_tokens_list = list(research_tokens.split(" "))
        ## get unique words of list
        reaserch_tokens_set = set(research_tokens_list)
        for rsch_token_set in reaserch_tokens_set:
            self.calc_tf_idf(research_id, research_tokens, rsch_token_set)

    def form_se_metrics(self, file_path, file_name):
        research_df = load_csv_to_df(file_path, file_name)
        for index in research_df.index:
            research_tokens = research_df['RSCH_TOKENS'][index]
            self.research_tokens_doc_list.append(research_tokens)

        for index in research_df.index:
            research_tokens = research_df['RSCH_TOKENS'][index]
            research_id = research_df['RSCH_ID'][index]
            self.calc_metrics_for_docs(research_id, research_tokens)

        self.research_metric_body_list.append(self.research_id_list)
        self.research_metric_body_list.append(self.research_token_list)
        self.research_metric_body_list.append(self.research_token_tf_list)
        self.research_metric_body_list.append(self.research_token_idf_list)
        self.research_metric_body_list.append(self.research_token_tf_idf_list)
        self.engine_utilities.update_dictionary(self.research_metric_header_list,
                                                self.research_metric_body_list)
        self.engine_utilities.create_member_df_save_csv("D:\\Development\\Custom_Data\\SearchEngine\\",
                                                        "METRICS.CSV")
