# import statements
import requests as req
import time as ts

from bs4 import BeautifulSoup as bs
from org.coventry.utils.utilities import EngineUtilities

class MemberCrawler:
    __slots__ = ['sefa_member_url', 'sefa_member_sub_query', 'sefa_member_counter','engine_utilities']

    # initialize properties
    def __init__(self):
        self.sefa_member_url = 'https://pureportal.coventry.ac.uk/en/organisations/school-of-economics-finance-and-accounting/persons/'
        self.sefa_member_sub_query = '?page='
        self.sefa_member_counter = 0
        self.engine_utilities = EngineUtilities()


    # Display variables
    def display_sefa_variables(self):
        print('url :: ', self.sefa_member_url)
        print('sub-query :: ', self.sefa_member_sub_query)
        print('counter :: ', self.sefa_member_counter)

    def crawl_save_member_details(self):
        member_name_list = []
        member_url_list = []
        member_id_list = []
        member_header_list = ['Member_ID', 'Member_NAME', 'Member_URL']
        member_body_list = []
        member_id_code = 'SEFA_M'
        member_id_seq = 00000
        is_iteration_required = True
        while is_iteration_required:
            sefa_final_url = self.sefa_member_url + self.sefa_member_sub_query + str(self.sefa_member_counter)
            ts.sleep(1)
            member_list_page = req.get(sefa_final_url)
            print('list-page :: ', member_list_page)
            if member_list_page.status_code == 200:
                self.sefa_member_counter += 1
                member_list_page_soup = bs(member_list_page.text, "html.parser")
                all_members = member_list_page_soup.find_all("a", class_="link person")
                print('no. of members :: ', len(all_members))
                if len(all_members) > 0:
                    for member in all_members:
                        print('Member Name :: ', member.string)
                        print('Member URL :: ', member.attrs['href'])
                        member_name_list.append(member.string)
                        member_url_list.append(member.attrs['href'])
                        member_id_list.append(member_id_code + str(member_id_seq))
                        member_id_seq += 1

                else:
                    is_iteration_required = False

            else:
                is_iteration_required = False

            member_body_list.append(member_id_list)
            member_body_list.append(member_name_list)
            member_body_list.append(member_url_list)

            self.engine_utilities.update_dictionary(member_header_list, member_body_list)
            self.engine_utilities.create_member_df_save_csv("D:\\Development\\Custom_Data\\SearchEngine\\",
                                                      "MEMBERS.csv")


